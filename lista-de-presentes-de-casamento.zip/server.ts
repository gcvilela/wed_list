import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "Wedding App API is running" });
  });

  // Mercado Pago Payment Integration
  // To use this in production:
  // 1. Install 'mercadopago'
  // 2. Import { MercadoPagoConfig, Preference } from 'mercadopago'
  // 3. Initialize: const client = new MercadoPagoConfig({ accessToken: process.env.MP_ACCESS_TOKEN });
  app.post("/api/payments/create", async (req, res) => {
    try {
      const { amount, description, payer } = req.body;
      
      /**
       * ESTRUTURA PARA MERCADO PAGO:
       * 
       * const preference = new Preference(client);
       * const response = await preference.create({
       *   body: {
       *     items: [{
       *       title: description,
       *       unit_price: Number(amount),
       *       quantity: 1,
       *       currency_id: 'BRL'
       *     }],
       *     payer: {
       *       name: payer.name,
       *       email: 'convidado@email.com' // Ideal capturar no modal
       *     },
       *     back_urls: {
       *       success: `${process.env.APP_URL}/success`,
       *       failure: `${process.env.APP_URL}/cart`,
       *       pending: `${process.env.APP_URL}/pending`
       *     },
       *     auto_return: 'approved',
       *     payment_methods: {
       *       excluded_payment_types: [{ id: 'ticket' }], // Exclui boleto se quiser apenas PIX/Cartão
       *       installments: 12 // Permite parcelamento
       *     }
       *   }
       * });
       */

      console.log("Simulando criação de preferência no Mercado Pago...");
      
      // Simulação de resposta bem-sucedida
      res.json({ 
        id: "pref_" + Math.random().toString(36).substr(2, 9),
        init_point: "https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=placeholder" 
      });
    } catch (error) {
      console.error("Erro no processamento do pagamento:", error);
      res.status(500).json({ error: "Erro interno no servidor de pagamentos" });
    }
  });

  // Webhook para notificações de pagamento
  app.post("/api/payments/webhook", async (req, res) => {
    // Aqui o Mercado Pago avisa quando o PIX foi pago ou o cartão aprovado
    // Você deve validar o 'topic' e 'id' recebidos
    console.log("Recebido Webhook do Mercado Pago:", req.body);
    res.sendStatus(200);
  });

  // Vite Integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
